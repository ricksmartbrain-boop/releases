# Rick free Tier v1.0.0

Thank you for installing Rick!

## Quick Start
1. Run: openclaw gateway start
2. Follow the setup wizard
3. Rick will begin operating within minutes

## Support
- Docs: https://meetrick.ai/docs
- Email: rick@meetrick.ai

## Tier: free
